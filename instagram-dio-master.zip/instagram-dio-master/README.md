# Oi, tudo bem? Chegou aqui através do curso, certo? 🙃

Esse é o repositório da nossa aula de Flexbox, na qual vamos fazer a interface de login do Instagram! 

### Os requisitos são:

* [HTML básico](https://www.w3schools.com/html/)
* [CSS básico](https://developer.mozilla.org/pt-BR/docs/Web/CSS)

## 🚀 Let's code! 🚀
